# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ownership.spec.ts >> layout pointer drag changes positions only; native folder drop saves complete filename and reloads the same intent
- Location: tests/e2e/ownership.spec.ts:702:1

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0

Call Log:
- Timeout 10000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - link "◈ AtlasMode Code facts · Visual planning" [ref=e5] [cursor=pointer]:
      - /url: "#"
      - text: ◈ AtlasMode
      - generic [ref=e6]: Code facts · Visual planning
    - button "Open project" [ref=e7] [cursor=pointer]
    - combobox "Switch project" [ref=e8]:
      - option "Choose an opened project"
      - option "project · /tmp/atlas-fs01-production-O8ndp6/project" [selected]
    - button "Refresh code" [ref=e9] [cursor=pointer]
    - button "Toggle light/dark" [ref=e10] [cursor=pointer]: ☾ Dark
    - combobox "Interface language" [ref=e11]:
      - option "中文"
      - option "English" [selected]
  - main [ref=e12]:
    - complementary "Project facts" [ref=e13]:
      - generic [ref=e14]:
        - text: Project facts
        - heading "project" [level=1] [ref=e15]
        - code [ref=e16]: /tmp/atlas-fs01-production-O8ndp6/project
      - paragraph [ref=e17]: Search for a function, or open Browse code to choose an entry. Click to inspect references; double-click for dependencies.
      - region "Search functions" [ref=e18]:
        - generic [ref=e19]:
          - textbox "Search functions" [ref=e20]:
            - /placeholder: Name, qualified name or path
            - text: selected
          - button "Search" [ref=e21] [cursor=pointer]
        - paragraph [ref=e22]: 1–1 / 1
        - button "ƒ selected src/original.ts" [ref=e24] [cursor=pointer]:
          - strong [ref=e25]: ƒ selected
          - generic [ref=e26]: src/original.ts
        - generic [ref=e27]:
          - button "Previous page" [disabled] [ref=e28]
          - button "Next page" [disabled] [ref=e29]
      - group [ref=e30]:
        - generic "Browse code" [ref=e31] [cursor=pointer]
        - generic [ref=e32]:
          - heading "Entry candidates 3/3" [level=2] [ref=e33]:
            - text: Entry candidates
            - generic [ref=e34]: 3/3
          - paragraph [ref=e35]: "TS/JS: explicit exports; Python: public top-level names. These are candidates, not confirmed runtime entries."
          - generic [ref=e36]:
            - button "ƒ destinationMarker dest/index.ts" [ref=e37] [cursor=pointer]:
              - strong [ref=e38]: ƒ destinationMarker
              - generic [ref=e39]: dest/index.ts
            - button "ƒ otherMarker other/index.ts" [ref=e40] [cursor=pointer]:
              - strong [ref=e41]: ƒ otherMarker
              - generic [ref=e42]: other/index.ts
            - button "ƒ selected src/original.ts" [ref=e43] [cursor=pointer]:
              - strong [ref=e44]: ƒ selected
              - generic [ref=e45]: src/original.ts
        - generic [ref=e46]:
          - heading "Browse routes" [level=2] [ref=e47]
          - combobox "Browse routes" [ref=e48]:
            - option "No route" [selected]
          - paragraph [ref=e49]: A route is an explanation sequence; it does not imply calls.
      - group [ref=e50]:
        - generic "AI exploration · connection and chat" [ref=e51] [cursor=pointer]
      - button "Manage groups" [ref=e52] [cursor=pointer]
      - button "Advanced controls" [ref=e53] [cursor=pointer]
    - generic [ref=e54]:
      - navigation "Location" [ref=e55]:
        - list [ref=e56]:
          - listitem [ref=e57]:
            - button "project" [ref=e58] [cursor=pointer]
          - listitem [ref=e59]:
            - generic [aria-hidden] [ref=e60]: ›
            - button "src" [ref=e61] [cursor=pointer]
          - listitem [ref=e62]:
            - generic [aria-hidden] [ref=e63]: ›
            - button "original.ts" [ref=e64] [cursor=pointer]
          - listitem [ref=e65]:
            - generic [aria-hidden] [ref=e66]: ›
            - button "selected" [ref=e67] [cursor=pointer]
      - generic [ref=e68]:
        - generic "Plan ownership" [ref=e69]:
          - button "Layout" [pressed] [ref=e70] [cursor=pointer]
          - button "Plan ownership" [ref=e71] [cursor=pointer]
        - button "Circle-select functions" [ref=e72] [cursor=pointer]
        - generic [ref=e73]:
          - text: Visible layers
          - combobox "Visible layers" [ref=e74]:
            - option "Facts + plan" [selected]
            - option "Fact"
            - option "Plan"
        - generic [ref=e75]:
          - text: New/reconnected relation type
          - combobox "New/reconnected relation type" [ref=e76]:
            - option "Calls" [selected]
            - option "Must call"
            - option "Must reuse"
      - generic [ref=e77]: Hover to preview links, click for references, double-click for the dependency funnel. Drag any card. Esc closes the map, then details, then the funnel.
      - generic "Code canvas" [ref=e78]:
        - application [ref=e79]:
          - generic [ref=e81]:
            - generic:
              - generic:
                - img:
                  - group "Edge from fact:file:051f04d5a949a693cbca7a68309bb0d9 to fact:function:a772fffefc902f70bad1b1deb95d3b3f" [ref=e82] [cursor=pointer]:
                    - generic [ref=e85]: Fact · Contains
                - img:
                  - group "Edge from fact:file:d37db8676c3c892db65b91d9be123e2d to fact:function:47b34b685426bfc7fdeccc27f463912b" [ref=e87] [cursor=pointer]:
                    - generic [ref=e90]: Fact · Contains
                - img:
                  - group "Edge from fact:function:47b34b685426bfc7fdeccc27f463912b to fact:function:a772fffefc902f70bad1b1deb95d3b3f" [ref=e92] [cursor=pointer]:
                    - generic [ref=e95]: Fact · Calls
              - generic:
                - group [ref=e99]:
                  - generic [ref=e100]:
                    - generic [ref=e101]:
                      - generic [ref=e102]: ● Code fact
                      - generic [ref=e103]: Folder
                    - strong [ref=e104]:
                      - generic [ref=e105]:
                        - generic [aria-hidden] [ref=e106]: 
                        - generic [ref=e107]: ./
                        - generic [ref=e108]: Folder
                    - code [ref=e109]: .
                - group [ref=e110]:
                  - generic [ref=e111]:
                    - generic [ref=e112]:
                      - generic [ref=e113]: ● Code fact
                      - generic [ref=e114]: Folder
                    - strong [ref=e115]:
                      - generic [ref=e116]:
                        - generic [aria-hidden] [ref=e117]: 
                        - generic [ref=e118]: dest/
                        - generic [ref=e119]: Folder
                    - code [ref=e120]: dest
                - group [ref=e121]:
                  - generic [ref=e122]:
                    - generic [ref=e124]:
                      - generic [ref=e125]: ● Code fact
                      - generic [ref=e126]: Function
                    - strong [ref=e127]:
                      - generic [ref=e128]:
                        - generic [aria-hidden] [ref=e129]: 
                        - generic [ref=e130]: destinationMarker()
                        - generic [ref=e131]: Function
                    - code [ref=e132]: dest/index.ts
                    - generic "export function destinationMarker()" [ref=e133]
                - group [ref=e135]:
                  - generic [ref=e136]:
                    - generic [ref=e138]:
                      - generic [ref=e139]: ● Code fact
                      - generic [ref=e140]: File
                    - strong [ref=e141]:
                      - generic [ref=e142]:
                        - generic [aria-hidden] [ref=e143]: 
                        - generic [ref=e144]: index.ts
                        - generic [ref=e145]: File
                    - code [ref=e146]: dest/index.ts
                - group [ref=e148]:
                  - generic [ref=e149]:
                    - generic [ref=e151]:
                      - generic [ref=e152]: ● Code fact
                      - generic [ref=e153]: File
                    - strong [ref=e154]:
                      - generic [ref=e155]:
                        - generic [aria-hidden] [ref=e156]: 
                        - generic [ref=e157]: original.ts
                        - generic [ref=e158]: File
                    - code [ref=e159]: src/original.ts
                - group [ref=e161]:
                  - generic [ref=e162]:
                    - generic [ref=e164]:
                      - generic [ref=e165]: ● Code fact
                      - generic [ref=e166]: Function
                    - strong [ref=e167]:
                      - generic [ref=e168]:
                        - generic [aria-hidden] [ref=e169]: 
                        - generic [ref=e170]: selected()
                        - generic [ref=e171]: Function
                    - code [ref=e172]: src/original.ts
                    - generic "export function selected()" [ref=e173]
                - group [ref=e175]:
                  - generic [ref=e176]:
                    - generic [ref=e177]:
                      - generic [ref=e178]: ● Code fact
                      - generic [ref=e179]: Folder
                    - strong [ref=e180]:
                      - generic [ref=e181]:
                        - generic [aria-hidden] [ref=e182]: 
                        - generic [ref=e183]: src/
                        - generic [ref=e184]: Folder
                    - code [ref=e185]: src
          - generic "Control Panel" [ref=e186]:
            - button "Zoom in" [ref=e187] [cursor=pointer]
            - button "Zoom out" [ref=e190] [cursor=pointer]
            - button "Fit view" [ref=e193] [cursor=pointer]
            - button "Toggle interaction" [ref=e196] [cursor=pointer]
          - complementary "Map of the loaded graph" [ref=e199]:
            - button "Expand map" [ref=e200] [cursor=pointer]
            - img "Graph overview" [ref=e202]
          - link "React Flow attribution" [ref=e211] [cursor=pointer]:
            - /url: https://reactflow.dev?utm_source=attribution
            - text: React Flow
        - generic:
          - generic: ↑ Into selection
          - generic: ↓ From selection
        - region "Reference details" [ref=e214]:
          - generic [ref=e215]:
            - heading "selected() Function" [level=2] [ref=e216]:
              - generic [ref=e217]:
                - generic [aria-hidden] [ref=e218]: 
                - generic [ref=e219]: selected()
                - generic [ref=e220]: Function
            - button "Close details" [ref=e221] [cursor=pointer]: ×
          - generic [ref=e222]:
            - paragraph [ref=e223]: Code fact
            - code [ref=e224]: src/original.ts:1
            - generic [ref=e225]: export function selected()
            - generic [ref=e226]:
              - button "Copy location" [ref=e227] [cursor=pointer]
              - button "View source" [ref=e228] [cursor=pointer]
            - generic [ref=e229]:
              - heading "↑ Calls to this function 0" [level=3] [ref=e230]:
                - text: ↑ Calls to this function
                - generic [ref=e231]: "0"
              - paragraph [ref=e232]: No records on this page
            - generic [ref=e233]:
              - heading "↓ Calls from this function 1 resolved on page / all calls 1" [level=3] [ref=e234]:
                - text: ↓ Calls from this function
                - generic [ref=e235]: 1 resolved on page / all calls 1
              - article [ref=e236]:
                - button "destinationMarker() Function dest/index.ts:1" [ref=e237] [cursor=pointer]:
                  - generic [ref=e238]:
                    - generic [aria-hidden] [ref=e239]: 
                    - generic [ref=e240]: destinationMarker()
                    - generic [ref=e241]: Function
                  - code [ref=e242]: dest/index.ts:1
                - generic [ref=e243]: selected → destinationMarker
                - code [ref=e244]: src/original.ts:1
                - generic [ref=e245]: destinationMarker()
            - generic [ref=e246]:
              - heading "Unresolved / external calls on this page 0" [level=3] [ref=e247]:
                - text: Unresolved / external calls on this page
                - generic [ref=e248]: "0"
              - paragraph [ref=e249]: No records on this page
            - paragraph [ref=e250]: Resolved calls reflect this snapshot; zero incoming calls means this static query has no records.
            - generic [ref=e251]:
              - button "Previous references" [disabled] [ref=e252]
              - button "Next references" [disabled] [ref=e253]
      - generic [ref=e254]:
        - generic [ref=e255]: "Code fact query budget: Expansion: up to 80 nodes / 240 relations; optionally 300 / 900."
        - generic [ref=e256]: Layout, theme and language saved automatically
    - complementary "Details panel" [ref=e257]:
      - region "Plan review" [ref=e258]:
        - button "Awaiting your review · 1" [ref=e259] [cursor=pointer]:
          - generic [aria-hidden] [ref=e261]: ▾
      - navigation [ref=e262]:
        - button "View source" [ref=e263] [cursor=pointer]
        - button "Advanced editing" [ref=e264] [cursor=pointer]
        - button "Implementation check" [ref=e265] [cursor=pointer]
        - button "Knowledge notes" [ref=e266] [cursor=pointer]
      - generic [ref=e267]:
        - region "Change list" [ref=e268]:
          - generic [ref=e269]:
            - heading "Ownership fixture" [level=2] [ref=e270]
            - generic [ref=e271]: r1 · Draft
          - generic [ref=e272]:
            - text: Choose plan
            - combobox "Choose plan" [ref=e273]:
              - option "Choose or create a plan"
              - option "Ownership fixture · r1" [selected]
          - paragraph [ref=e274]: ○ No valid current approval
          - group [ref=e275]:
            - generic "Change list (0)" [ref=e276] [cursor=pointer]
            - paragraph [ref=e277]: No semantic changes yet
          - generic [ref=e278]:
            - button "Undo" [disabled] [ref=e279]
            - button "Redo" [disabled] [ref=e280]
            - button "Validate plan" [ref=e281] [cursor=pointer]
            - button "Confirm this plan" [ref=e282] [cursor=pointer]
          - generic [ref=e283]:
            - button "Export Markdown" [ref=e284] [cursor=pointer]
            - button "Export JSON" [ref=e285] [cursor=pointer]
            - button "Check approved implementation" [ref=e286] [cursor=pointer]
        - group [ref=e287]:
          - generic "AI planning · connection and chat" [ref=e288] [cursor=pointer]
```

# Test source

```ts
  625 |         },
  626 |         null,
  627 |         2,
  628 |       ),
  629 |     );
  630 |     await page.screenshot({
  631 |       path: info.outputPath("ownership-expired.png"),
  632 |       fullPage: true,
  633 |     });
  634 |   } finally {
  635 |     await f.dispose();
  636 |   }
  637 | });
  638 | test("a real late context cannot dispatch old source after another function selection", async ({
  639 |   page,
  640 |   context,
  641 | }, info) => {
  642 |   const f = await setup(page, context, info);
  643 |   let release: (() => void) | undefined;
  644 |   let held = false;
  645 |   const sourcePaths: string[] = [];
  646 |   try {
  647 |     await context.route(
  648 |       `**/api/projects/${encodeURIComponent(f.project.id)}/functions/${encodeURIComponent(f.selected.id)}?*`,
  649 |       async (route) => {
  650 |         if (held) return route.continue();
  651 |         held = true;
  652 |         const response = await route.fetch();
  653 |         await new Promise<void>((resolve) => {
  654 |           release = resolve;
  655 |         });
  656 |         await route.fulfill({ response });
  657 |       },
  658 |     );
  659 |     page.on("request", (request) => {
  660 |       const url = new URL(request.url());
  661 |       if (apiPath(request.url()).endsWith("/source"))
  662 |         sourcePaths.push(url.searchParams.get("filePath") ?? "");
  663 |     });
  664 |     await page
  665 |       .locator(".inspector")
  666 |       .getByRole("button", { name: "View source", exact: true })
  667 |       .click();
  668 |     await expect.poll(() => !!release).toBe(true);
  669 |     await page
  670 |       .getByRole("textbox", { name: "Search functions", exact: true })
  671 |       .fill("destinationMarker");
  672 |     await page.getByRole("button", { name: "Search", exact: true }).click();
  673 |     await page
  674 |       .getByRole("region", { name: "Search functions", exact: true })
  675 |       .getByRole("button", { name: /ƒ destinationMarker/ })
  676 |       .click();
  677 |     await expect(page.locator(".inspector")).toContainText("DESTINATION bytes");
  678 |     release!();
  679 |     await expect(page.locator(".inspector")).not.toContainText(
  680 |       "ORIGINAL bytes",
  681 |     );
  682 |     expect(sourcePaths).toEqual(["dest/index.ts"]);
  683 |     await f.assertSource();
  684 |     await writeFile(
  685 |       info.outputPath("source-context-generation.json"),
  686 |       JSON.stringify(
  687 |         {
  688 |           sourcePaths,
  689 |           before: f.before,
  690 |           after: await sourceReceipt(f.projectPath),
  691 |         },
  692 |         null,
  693 |         2,
  694 |       ),
  695 |     );
  696 |   } finally {
  697 |     release?.();
  698 |     await f.dispose();
  699 |   }
  700 | });
  701 | 
  702 | test("layout pointer drag changes positions only; native folder drop saves complete filename and reloads the same intent", async ({
  703 |   page,
  704 |   context,
  705 | }, info) => {
  706 |   const f = await setup(page, context, info);
  707 |   try {
  708 |     await expect(
  709 |       page.getByRole("button", { name: "Layout", exact: true }),
  710 |     ).toHaveAttribute("aria-pressed", "true");
  711 |     const before = await f.api(`/api/plans/${f.detail.plan.id}`),
  712 |       box = await f.card.boundingBox();
  713 |     if (!box) throw new Error("Missing layout card");
  714 |     await page.mouse.move(box.x + 70, box.y + 35);
  715 |     await page.mouse.down();
  716 |     await page.mouse.move(box.x + 125, box.y + 65, { steps: 12 });
  717 |     await page.mouse.up();
  718 |     await expect
  719 |       .poll(
  720 |         async () =>
  721 |           Object.keys(
  722 |             (await f.api(`/api/projects/${f.project.id}/view`)).positions,
  723 |           ).length,
  724 |       )
> 725 |       .toBeGreaterThan(0);
      |        ^ Error: expect(received).toBeGreaterThan(expected)
  726 |     expect((await f.api(`/api/plans/${f.detail.plan.id}`)).plan).toEqual(
  727 |       before.plan,
  728 |     );
  729 |     expect(
  730 |       await page.evaluate(
  731 |         () =>
  732 |           (window as unknown as { ownershipEvents: unknown[] }).ownershipEvents,
  733 |       ),
  734 |     ).toEqual([]);
  735 |     await chooseFolder(page, f.card);
  736 |     const panel = preview(page);
  737 |     await panel
  738 |       .getByRole("textbox", { name: "Complete source filename", exact: true })
  739 |       .fill("owned.ts");
  740 |     await expect(panel.getByTestId("ownership-full-path")).toHaveText(
  741 |       "dest/owned.ts",
  742 |     );
  743 |     await save(page, f.detail.plan.id, 1, f.summary.snapshotId);
  744 |     await expect
  745 |       .poll(
  746 |         async () =>
  747 |           (await f.api(`/api/plans/${f.detail.plan.id}`)).plan.revision,
  748 |       )
  749 |       .toBe(2);
  750 |     const saved = await f.api(`/api/plans/${f.detail.plan.id}`);
  751 |     expect(saved.plan.operations).toEqual([
  752 |       {
  753 |         kind: "move_function",
  754 |         nodeId: f.selected.id,
  755 |         filePath: "dest/owned.ts",
  756 |       },
  757 |     ]);
  758 |     await page.reload();
  759 |     await openCodeNavigation(page);
  760 |     await page
  761 |       .getByRole("combobox", { name: "Choose plan", exact: true })
  762 |       .first()
  763 |       .selectOption(f.detail.plan.id);
  764 |     await expect(page.locator(".plan-overview")).toContainText("dest/owned.ts");
  765 |     expect((await f.api(`/api/plans/${f.detail.plan.id}`)).plan).toEqual(
  766 |       saved.plan,
  767 |     );
  768 |     await f.assertSource();
  769 |     await writeFile(
  770 |       info.outputPath("layout-folder-receipt.json"),
  771 |       JSON.stringify(
  772 |         {
  773 |           before,
  774 |           saved,
  775 |           view: await f.api(`/api/projects/${f.project.id}/view`),
  776 |           beforeFiles: f.before,
  777 |           afterFiles: await sourceReceipt(f.projectPath),
  778 |         },
  779 |         null,
  780 |         2,
  781 |       ),
  782 |     );
  783 |   } finally {
  784 |     await f.dispose();
  785 |   }
  786 | });
  787 | 
  788 | test("a folded group endpoint native drag saves the real function ID and retains membership across reload", async ({
  789 |   page,
  790 |   context,
  791 | }, info) => {
  792 |   const f = await setup(page, context, info);
  793 |   try {
  794 |     const beforeGroupPlan = await f.api(`/api/plans/${f.detail.plan.id}`);
  795 |     const group = await f.api(`/api/projects/${f.project.id}/groups`, "POST", {
  796 |       title: "Owned members",
  797 |       description: "unchanged grouping",
  798 |       source: "user",
  799 |       memberIds: [f.selected.id],
  800 |     });
  801 |     const afterGroupPlan = await f.api(`/api/plans/${f.detail.plan.id}`);
  802 |     expect(afterGroupPlan.plan.revision).toBe(
  803 |       beforeGroupPlan.plan.revision + 1,
  804 |     );
  805 |     expect(afterGroupPlan.plan.baselineSnapshotId).toBe(f.summary.snapshotId);
  806 |     await page.reload();
  807 |     await openCodeNavigation(page);
  808 |     await page
  809 |       .getByRole("combobox", { name: "Choose plan", exact: true })
  810 |       .first()
  811 |       .selectOption(f.detail.plan.id);
  812 |     await page
  813 |       .getByRole("textbox", { name: "Search functions", exact: true })
  814 |       .fill("selected");
  815 |     await page.getByRole("button", { name: "Search", exact: true }).click();
  816 |     await page
  817 |       .getByRole("region", { name: "Search functions", exact: true })
  818 |       .getByRole("button", { name: /ƒ selected/ })
  819 |       .click();
  820 |     await page
  821 |       .getByRole("button", { name: "Collapse Owned members", exact: true })
  822 |       .click();
  823 |     const endpoint = page.locator(
  824 |       `.group-endpoint[data-domain-id="${f.selected.id}"]`,
  825 |     );
```