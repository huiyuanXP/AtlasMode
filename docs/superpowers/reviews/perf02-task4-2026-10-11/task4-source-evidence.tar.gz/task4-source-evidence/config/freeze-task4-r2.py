import json, hashlib, shutil, subprocess
from pathlib import Path
owner=Path("/home/agent/projects/AtlasMode-checkpoints/2026-10-11-perf02-task4")
work=owner/"workspace"; ev=owner/"evidence"; old=ev/"review-package"; new=ev/"review-package-r2"
if new.exists(): raise SystemExit("R2 package already exists; refusing overwrite")
x=json.loads((old/"source-manifest.json").read_text()); new.mkdir()
for f in x["sha256"]:
    p=new/"source"/f; p.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(work/f,p)
    x["sha256"][f]=hashlib.sha256((work/f).read_bytes()).hexdigest()
(new/"source-manifest.json").write_text(json.dumps(x,indent=2)+"\n")
shutil.copytree(old/"baseline",new/"baseline")
(new/"source-diff.patch").write_bytes(subprocess.check_output(["git","-C",str(work),"diff","--binary","--",*x["changed"]]))
for p in ev.iterdir():
    if p.is_file() and (p.name.startswith("task4-") or p.name.startswith("canvas-r1-") or p.name=="assembled-prior.json"):
        shutil.copy2(p,new/p.name)
shutil.copytree(owner/"config",new/"config")
(new/"README.md").write_text("# Frozen R2 — limited independent closure\nReview only R1 I1/I2/I3/M1 repairs, exact changed source and new RED/GREEN/final gates. Preserve R1 verdict. No Task5 production Worker/DOM/scale claims. Author gate logs task4-r2-*; source-manifest identifies41 exact sources and30 source changes. Current prior assembly14 must remain unchanged.\n")
(new/"repair-matrix.md").write_text("I1: cached actual bound exact projection identity+generation; fresh producer guard. I2: authoritative undefined callback veto, current store ownership/dirty/draft/busy/funnel gate, transition generations. I3: bounded sameproject/scope compact cache retains only survivors across snapshot, current-display exact snapshot, explicit recompute ignores retained. M1: complete conservative route upper-bound vs early observed estimates labeled.\n")
print("R2 frozen",len(x["sha256"]),"sources")
