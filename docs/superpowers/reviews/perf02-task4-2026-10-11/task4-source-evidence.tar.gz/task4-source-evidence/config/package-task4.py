import hashlib, shutil, tarfile, json
from pathlib import Path
owner=Path("/home/agent/projects/AtlasMode-checkpoints/2026-10-11-perf02-task4")
ev=owner/"evidence"; work=owner/"workspace"; dest=work/"docs/superpowers/reviews/perf02-task4-2026-10-11"
stage=owner/"delivery-evidence"
if stage.exists(): raise SystemExit("Refusing overwrite existing delivery evidence")
stage.mkdir(); shutil.copytree(ev,stage/"evidence"); shutil.copytree(owner/"config",stage/"config"); shutil.copy2(owner/"progress.md",stage/"progress.md")
lines=[]
for p in sorted(stage.rglob("*")):
 if p.is_file(): lines.append(hashlib.sha256(p.read_bytes()).hexdigest()+"  "+str(p.relative_to(stage)))
(stage/"MANIFEST.sha256").write_text("\n".join(lines)+"\n")
archive=dest/"task4-source-evidence.tar.gz"
with tarfile.open(archive,"w:gz") as tar: tar.add(stage,arcname="task4-source-evidence")
(dest/"task4-source-evidence.sha256").write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+"  task4-source-evidence.tar.gz\n")
print("Archive",archive.stat().st_size,"bytes",len(lines),"files")
