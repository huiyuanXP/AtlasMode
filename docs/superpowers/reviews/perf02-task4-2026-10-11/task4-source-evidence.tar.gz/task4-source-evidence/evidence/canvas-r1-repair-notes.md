# Task4 Canvas/session R1 directed repair

Read the full independent report `task4-independent-review.md` (REQUEST_CHANGES C0/I3/M1). This is one authorized repair pass, limited to I1–I3 and M1. Product source writes stopped after `canvas-r1-final-source.sha256`; original R1 package, manifests, reports and RED logs remain unchanged. Workspace store changes are controller-owned.

| Finding | Concrete repair and source-level regression |
|---|---|
| I1 cached measurements | `OverviewMeasurementFrame` owns exact rawProjection reference and projectionGeneration, separately from stable retention scope. `readOverviewMeasurements` and actual Canvas `completeOverviewFrame` refuse a previous frame even when every visual ID is reused. Producer callback also checks the currently bound identity before/inside the state update. Direct caller fixture observes pending with no apply/save for old 300×80 boxes, then ready with current first-card300×600 and second-card y648. `session.isCurrent` prevents an obsolete passive effect token from clearing a newer job after measurement replacement. |
| I2 live veto | `resolveCurrentOverviewCapture` uses the props capture only when the callback is absent; a present callback returning undefined remains a veto. `completeOverviewJob` reads current capture and blockers before measuring and immediately before default adoption/explicit save. Canvas also includes current producer identity and synchronous drag ref in this live guard. Valid default adoption remains derived; ordinary drag uses the same authoritative resolver with its gesture-start capture. Controller capture/save protects accepted live ownership/intent/dirty/group/funnel/selection/loading transitions and increments cancellation generations. |
| I3 compact retention | `CompactOverviewCache` retains at most two projects, one accepted bounded500-card scope per project. Navigation/filter/collapse retention scope excludes snapshot freshness. New measured jobs receive only surviving current visual IDs; current display still requires exact snapshot. Current pins and dimensions are revalidated by accepted layout helper. Explicit visible reflow continues ignoring its current pins and retained points; a same-snapshot new global result drops retained compact autos for explicit full-project recompute. Refresh fixture keeps fact:1 exactly y128 while the new fact finds an empty position; previous snapshot does not masquerade as current ready. |
| M1 truthful diagnostics | Complete refusal now labels card estimates separately from conservative route upper bounds that have not been generated. Early refusal reports observed route-estimate subtotal, not an emitted-edge lower bound. Raw graph lengths remain separately displayed. Real SSR group-work fixture checks route upper bound241 and avoids an exact visual-count claim. |

New evidence only:

- `canvas-r1-repair-red.log`: two files,14 failed/24 passed.
- `canvas-r1-repair-green-1.log`: two files38/38 passed.
- `canvas-r1-frame-caller-red.log`: stale frame caller returned ready;1 failed/35 passed.
- `canvas-r1-effect-token-red.log`: stale frame/token caller;2 failed/35 passed.
- `canvas-r1-final-green.log`: final two files42/42 passed (session37,Canvas SSR5).
- `canvas-r1-final-lint.log`: final seven-owned-file ESLint exit0.
- `canvas-r1-final-source.sha256`: exact final product/test bytes. WorkspacePanels remains unchanged from R1.

Remaining: controller final unified regression/typecheck and limited independent re-review. No production Worker, real DOM/effect timing, actual pointer/browser, project timing or Task5 acceptance was run; source-level callers and SSR do not stand in for those receipts. No build/stage/commit/push/deploy or accepted helper source edits were performed.
