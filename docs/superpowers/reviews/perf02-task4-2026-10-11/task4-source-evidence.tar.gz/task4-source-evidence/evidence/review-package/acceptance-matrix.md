| Task4 contract | Evidence | Status |
|---|---|---|
| accepted FS/GRP window | latest baseline tickets/review refs, source hashes | verified |
| target bound id/hash/complete | store delayed/hash/rejected tests, real SQLite HTTP13 | PASS source/HTTP |
| default worker + no default save | store ready leaves view unchanged; bounded controller reused | PASS double; realWorkerTask5 |
| generations/project late cancellation | store project/S1/filter/groups/plan/graph/nav/view cases | PASS |
| cache/disposal/recompute | store2project bounded retention and late disposal result | PASS |
| preflight before projectors | session refusal tests + Canvas SSR unsafe projection tests | PASS source |
| two-pass atomic geometry | session livecap secondfailure lackspositions + cumulative accounting | PASS helper; DOMTask5 |
| measured provenance/stability | Canvas accepts current projectionData/full dimensions; session<=1px | PASS source; DOMTask5 |
| drag/currentreflow captured patch | startcapture draghelper2tests + store epoch + capturemerge | PASS source; pointerTask5 |
| saved opaque/hiddencanonical | store currentmerge retains them | PASS source; restartTask5 |
| ownership/funnel/groups | blocked session/button tests; accepted interaction regressions | PASS source; nativeTask5 |
| failure/retryviewsave | localviewUnsaved and retry store test | PASS |
| identities/approval | no semantic API from layout; HTTPbeforeafter; projection reused unchanged | PASS source/HTTP |
| final checks | 19files194PASS/noEmit/lint0 | PASS |
| real production/scale/performance | worker asset/DOM/ExpressFlask10runs/restart/Vite | NOT RUN Task5 |
