import { describe, expect, it, vi } from "vitest";
import type {
  CodeNode,
  Operation,
  SubgraphResult,
  FunctionGroup,
} from "@codemap/core";
import * as graphModule from "./projection.js";
import * as groupModule from "../groups/projection.js";
import {
  guardedOverviewProjection,
  OverviewSession,
  measurementsChanged,
  type OverviewSessionInput,
  saveCapturedVisualPosition,
} from "./overview-session.js";
import { layoutProjectFacts } from "./overview-layout.js";
const node = (id: string): CodeNode => ({
  id,
  name: id,
  kind: "function",
  filePath: "a.ts",
});
const graph = (n = 2): SubgraphResult => ({
  snapshotId: "s",
  dataSource: "code",
  truncated: false,
  nodes: Array.from({ length: n }, (_, i) => node(String(i))),
  relations: [],
});
const capture = {
  projectId: "p",
  snapshotId: "s",
  projectionGeneration: 1,
  viewGeneration: 1,
};
function input(n = 2): OverviewSessionInput {
  const g = graph(n),
    projection = graphModule.projectGraph(g, [], "fact", {});
  const global = layoutProjectFacts({
    target: {
      projectId: "p",
      snapshotId: "s",
      contentHash: "hash",
      scope: "project_indexed_facts",
      status: "ready",
      complete: true,
      limits: { nodes: 5000, relations: 20000, bytes: 8388608 },
      counts: {
        nodes: n,
        relations: 0,
        byKind: { function: n, file: 0, folder: 0, external: 0 },
      },
      nodes: g.nodes.map((x) => ({ id: x.id, kind: x.kind })),
      relations: [],
    },
    pins: {},
    retained: {},
  });
  if (global.status !== "ready") throw Error("fixture");
  return {
    projection,
    global,
    pins: {},
    retained: {},
    ignorePinsFor: [],
    capture,
    measurementGeneration: 0,
  };
}
const dimensions = {
  "fact:0": { width: 200, height: 80 },
  "fact:1": { width: 250, height: 90 },
};
describe("guarded overview projection", () => {
  it("never projects a rejected planned layer and independently builds bounded fact-only fallback", () => {
    const ops: Operation[] = Array.from({ length: 2001 }, (_, i) => ({
      kind: "add_relation",
      id: String(i),
      sourceId: "0",
      targetId: "1",
      type: "calls",
    }));
    const p = vi.spyOn(graphModule, "projectGraph"),
      groups = vi.spyOn(groupModule, "projectGroups");
    const result = guardedOverviewProjection({
      graph: graph(),
      operations: ops,
      filter: "both",
      references: [node("extra")],
      groups: [],
      collapsed: [],
      positions: {},
      locale: "en",
    });
    expect(result.rejection).toMatchObject({
      reason: "edge_budget",
      countStatus: "partial_lower_bound",
      edgesLowerBound: 2001,
    });
    expect(result.fallback).toBe("facts");
    expect(result.projection.nodes.map((n) => n.id)).toEqual([
      "fact:0",
      "fact:1",
    ]);
    expect(p).toHaveBeenCalledTimes(1);
    expect(p.mock.calls[0]?.slice(1, 3)).toEqual([[], "fact"]);
    expect(p.mock.calls[0]?.[5]).toEqual([]);
    expect(groups).not.toHaveBeenCalled();
    vi.restoreAllMocks();
  });
  it("keeps an oversized raw graph empty without projecting or truncating it", () => {
    const p = vi.spyOn(graphModule, "projectGraph");
    const r = guardedOverviewProjection({
      graph: graph(301),
      operations: [],
      filter: "plan",
      references: [],
      groups: [],
      collapsed: [],
      positions: {},
      locale: "zh",
    });
    expect(r.fallback).toBe("empty");
    expect(r.projection.nodes).toEqual([]);
    expect(p).not.toHaveBeenCalled();
    vi.restoreAllMocks();
  });
  it("ignores huge fact-hidden operations while reporting exact stored length", () => {
    const operations = new Proxy(Array(4097), {
      get(t, k) {
        if (k !== "length") throw Error("unbounded op read");
        return Reflect.get(t, k);
      },
    }) as Operation[];
    const r = guardedOverviewProjection({
      graph: graph(),
      operations,
      filter: "fact",
      references: [],
      groups: [],
      collapsed: [],
      positions: {},
      locale: "zh",
    });
    expect(r.rejection).toBeUndefined();
    expect(r.estimate.counts).toMatchObject({
      storedOperations: 4097,
      visibleOperations: 0,
    });
    expect(r.projection.nodes).toHaveLength(2);
  });
  it("rejects amplified group work before projectGroups and excludes all groups from fallback", () => {
    const groups: FunctionGroup[] = Array.from({ length: 4097 }, (_, i) => ({
      id: String(i),
      projectId: "p",
      title: "group",
      description: "",
      source: "user",
      memberIds: ["0"],
    }));
    const p = vi.spyOn(groupModule, "projectGroups"),
      r = guardedOverviewProjection({
        graph: graph(),
        operations: [],
        filter: "both",
        references: [],
        groups,
        collapsed: [],
        positions: {},
        locale: "en",
      });
    expect(r.rejection).toMatchObject({ reason: "membership_work" });
    expect(r.fallback).toBe("facts");
    expect(r.projection.nodes).toHaveLength(2);
    expect(p).not.toHaveBeenCalled();
    vi.restoreAllMocks();
  });
});
describe("overview measurement session", () => {
  it("stages fallback without positions and waits for every actual card before a single complete result", () => {
    const s = new OverviewSession(),
      begin = s.begin(input());
    expect(begin.status).toBe("pending");
    expect(begin).not.toHaveProperty("positions");
    if (begin.status !== "pending") return;
    expect(
      s.measure(begin.token, { "fact:0": dimensions["fact:0"] }, capture),
    ).toMatchObject({ status: "pending" });
    const r = s.measure(begin.token, dimensions, capture);
    expect(r).toMatchObject({ status: "ready", geometry: { passes: 2 } });
    if (r.status !== "ready") return;
    expect(r.positions["fact:1"]!.y).toBeGreaterThanOrEqual(128);
    expect(s.measure(begin.token, dimensions, capture).status).toBe(
      "cancelled",
    );
  });
  it("rejects a second-pass geometry failure without exposing the first candidate", () => {
    const s = new OverviewSession(),
      b = s.begin(input());
    expect(b.status).toBe("pending");
    if (b.status !== "pending") return;
    const r = s.measure(
      b.token,
      { ...dimensions, "fact:1": { width: 100000, height: 100000 } },
      capture,
    );
    expect(r).toMatchObject({ status: "rejected", geometry: { passes: 2 } });
    expect(r).not.toHaveProperty("positions");
  });
  it("charges both passes cumulatively", () => {
    const s = new OverviewSession(),
      b = s.begin(input());
    expect(b.status).toBe("pending");
    if (b.status !== "pending") return;
    const r = s.measure(b.token, dimensions, capture);
    expect(r).toMatchObject({
      status: "ready",
      geometry: { passes: 2, candidateProbes: 4, cellEntriesInserted: 4 },
    });
  });
  it.each([
    "projectId",
    "snapshotId",
    "projectionGeneration",
    "viewGeneration",
  ] as const)("cancels a late measurement when %s changes", (key) => {
    const s = new OverviewSession(),
      b = s.begin(input());
    expect(b.status).toBe("pending");
    if (b.status !== "pending") return;
    const current = {
      ...capture,
      [key]: typeof capture[key] === "number" ? 2 : "changed",
    };
    expect(s.measure(b.token, dimensions, current).status).toBe("cancelled");
  });
  it("blocks layout during ownership, dirty editing, funnel, selection and dragging", () => {
    for (const flag of [
      "ownership",
      "dirty",
      "funnel",
      "selection",
      "dragging",
    ]) {
      const s = new OverviewSession();
      expect(s.begin({ ...input(), blocked: { [flag]: true } }).status).toBe(
        "cancelled",
      );
    }
  });
  it("cancellation invalidates a token and newer sessions cannot be completed with old measurements", () => {
    const s = new OverviewSession(),
      a = s.begin(input());
    expect(a.status).toBe("pending");
    if (a.status !== "pending") return;
    s.cancel();
    const b = s.begin(input());
    expect(s.measure(a.token, dimensions, capture).status).toBe("cancelled");
    expect(b.status).toBe("pending");
    if (b.status !== "pending") return;
    expect(s.measure(b.token, dimensions, capture).status).toBe("ready");
  });
  it("rejects stale measurement generation instead of publishing positions", () => {
    const s = new OverviewSession(),
      b = s.begin(input());
    expect(b.status).toBe("pending");
    if (b.status !== "pending") return;
    expect(s.measure(b.token, dimensions, capture, 1)).toEqual({
      status: "cancelled",
    });
  });
  it("fails a real second-pass live-entry budget without publishing a first-pass candidate", () => {
    const s = new OverviewSession(),
      b = s.begin(input(500));
    expect(b.status).toBe("pending");
    if (b.status !== "pending") return;
    const boxes = Object.fromEntries(
      Array.from({ length: 500 }, (_, i) => [
        `fact:${i}`,
        { width: 3000, height: 3000 },
      ]),
    );
    const r = s.measure(b.token, boxes, capture);
    expect(r).toMatchObject({
      status: "rejected",
      reason: "work_budget",
      geometry: { passes: 2, liveCellEntries: 20000 },
    });
    expect(r).not.toHaveProperty("positions");
  });
  it("explicit rearrange ignores only current visual pins while preserving original projection and opaque keys", () => {
    const x = input();
    x.pins = {
      "fact:0": { position: { x: 999, y: 999 }, sourceKey: "fact:0" },
    };
    x.ignorePinsFor = ["fact:0", "fact:1"];
    const before = structuredClone(x),
      s = new OverviewSession(),
      b = s.begin(x);
    expect(b.status).toBe("pending");
    if (b.status !== "pending") return;
    const r = s.measure(b.token, dimensions, capture);
    expect(r.status).toBe("ready");
    if (r.status !== "ready") return;
    expect(r.positions["fact:0"]).toEqual({ x: 0, y: 0 });
    expect(Object.keys(r.positions).sort()).toEqual(["fact:0", "fact:1"]);
    expect(x).toEqual(before);
  });
  it("ignores measured jitter of at most one pixel", () => {
    expect(
      measurementsChanged(dimensions, {
        ...dimensions,
        "fact:0": { width: 201, height: 79 },
      }),
    ).toBe(false);
    expect(
      measurementsChanged(dimensions, {
        ...dimensions,
        "fact:0": { width: 202, height: 80 },
      }),
    ).toBe(true);
  });
});

describe("captured pointer layout patch", () => {
  it("refuses an old drag completion after switching project instead of saving it into the new scope", () => {
    let positions = { opaque: { x: 7, y: 8 } };
    const accepted = saveCapturedVisualPosition(
      "group-member:G:0",
      { x: 10, y: 20 },
      capture,
      { ...capture, projectId: "new" },
      (patch) => {
        positions = { ...positions, ...patch };
        return true;
      },
    );
    expect(accepted).toBe(false);
    expect(positions).toEqual({ opaque: { x: 7, y: 8 } });
  });
  it("saves only the dragged visual alias, preserving canonical and offscope positions", () => {
    let positions: Record<string, { x: number; y: number }> = {
      "fact:0": { x: 1, y: 2 },
      opaque: { x: 7, y: 8 },
    };
    expect(
      saveCapturedVisualPosition(
        "group-member:G:0",
        { x: 10, y: 20 },
        capture,
        capture,
        (patch) => {
          positions = { ...positions, ...patch };
          return true;
        },
      ),
    ).toBe(true);
    expect(positions).toEqual({
      "fact:0": { x: 1, y: 2 },
      opaque: { x: 7, y: 8 },
      "group-member:G:0": { x: 10, y: 20 },
    });
  });
});
