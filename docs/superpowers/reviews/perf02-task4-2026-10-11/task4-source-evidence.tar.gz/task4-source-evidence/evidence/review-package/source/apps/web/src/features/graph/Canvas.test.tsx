import { describe, expect, it, vi } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
import type { ComponentProps } from "react";
import { Canvas } from "./Canvas.js";
import { LocaleProvider } from "../../i18n/index.js";
import * as projection from "./projection.js";
import * as groups from "../groups/projection.js";
const base: ComponentProps<typeof Canvas> = {
  projectId: "p",
  operations: [],
  view: { positions: {}, collapsedGroupIds: [], theme: "light", locale: "en" },
  filter: "fact",
  onFunnel: () => {},
  onExitFunnel: () => {},
  canEdit: false,
  relationType: "calls",
  onSelect: () => {},
  onLayout: () => {},
  onEdge: () => {},
  onConnect: () => {},
};
const render = (props: Record<string, unknown> = {}) =>
  renderToStaticMarkup(
    <LocaleProvider locale="en">
      <Canvas {...base} {...props} />
    </LocaleProvider>,
  );
describe("overview Canvas controls and refusal", () => {
  it("shows both explicit overview actions with current-view replacement scope", () => {
    const html = render();
    expect(html).toContain("Recompute project auto layout");
    expect(html).toContain("Rearrange current view");
    expect(html).toContain("Other positions are retained");
  });
  it("renders a refused raw scope empty without allocating projected cards", () => {
    const p = vi.spyOn(projection, "projectGraph"),
      g = vi.spyOn(groups, "projectGroups");
    const html = render({
      graph: {
        snapshotId: "s",
        dataSource: "code",
        truncated: false,
        nodes: Array.from({ length: 301 }, (_, i) => ({
          id: String(i),
          name: String(i),
          kind: "function",
        })),
        relations: [],
      },
    });
    expect(html).toContain("Scope incomplete");
    expect(html).toContain("301");
    expect(p).not.toHaveBeenCalled();
    expect(g).not.toHaveBeenCalled();
    vi.restoreAllMocks();
  });
  it("states exact global target facts separately from visible card scope", () => {
    const html = render({
      overviewLayout: {
        status: "rejected",
        reason: "node_budget",
        target: { counts: { nodes: 5001, relations: 200 } },
      },
    });
    expect(html).toContain("5001");
    expect(html).toContain("200");
    expect(html).toContain("node_budget");
    expect(html).toContain("Current display");
  });
  it("disables overview actions for accepted ownership mode and unsaved editing", () => {
    const html = render({
      overviewBlocked: true,
      ownershipMode: true,
      onRecomputeProjectLayout: () => {},
      layoutCapture: {
        projectId: "p",
        snapshotId: "s",
        viewGeneration: 1,
        projectionGeneration: 1,
      },
    });
    expect(html).toMatch(
      /<button[^>]*disabled=""[^>]*>Recompute project auto layout<\/button>/,
    );
    expect(html).toMatch(
      /<button[^>]*disabled=""[^>]*>Rearrange current view<\/button>/,
    );
  });
});
