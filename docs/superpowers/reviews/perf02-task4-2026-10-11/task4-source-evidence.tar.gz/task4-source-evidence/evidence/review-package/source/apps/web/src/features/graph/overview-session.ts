import type {
  CodeNode,
  FunctionGroup,
  Operation,
  SubgraphResult,
  ViewState,
} from "@codemap/core";
import { projectGraph, type LayerFilter } from "./projection.js";
import { projectGroups } from "../groups/projection.js";
import {
  estimateBaseVisualWork,
  estimateVisualWork,
  layoutVisibleOverview,
  type LayoutBox,
  type Projection,
  type ProjectionEstimate,
  type VisibleLayoutInput,
  type VisibleLayoutResult,
} from "./overview-visual.js";
import type { GeometryWork } from "./overview-layout.js";
export type OverviewCapture = {
  projectId: string;
  snapshotId: string;
  projectionGeneration: number;
  viewGeneration: number;
};
export type OverviewProjectionInput = {
  graph?: SubgraphResult;
  operations: readonly Operation[];
  filter: LayerFilter;
  references: readonly CodeNode[];
  groups: readonly FunctionGroup[];
  collapsed: readonly string[];
  positions: ViewState["positions"];
  locale: ViewState["locale"];
  skipGroups?: boolean;
};
export type GuardedProjection = {
  projection: Projection;
  base: Projection;
  estimate: ProjectionEstimate;
  rejection?: Extract<ProjectionEstimate, { status: "rejected" }>;
  fallback?: "facts" | "empty";
};
/** Refused layers never reach their projector. Fallback earns its own budget,
 * with no operations, references or groups from the refused scope. */
export function guardedOverviewProjection(
  input: OverviewProjectionInput,
): GuardedProjection {
  const estimate = estimateBaseVisualWork(
    input.graph,
    input.operations,
    input.filter,
    input.references,
  );
  const fallback = (
    rejection: Extract<ProjectionEstimate, { status: "rejected" }>,
  ): GuardedProjection => {
    const safe = estimateBaseVisualWork(input.graph, [], "fact", []);
    const base: Projection =
      input.graph && safe.status === "ready"
        ? projectGraph(
            input.graph,
            [],
            "fact",
            input.positions,
            input.locale,
            [],
          )
        : { nodes: [], edges: [], notices: [] };
    return {
      projection: base,
      base,
      estimate,
      rejection,
      fallback: input.graph && safe.status === "ready" ? "facts" : "empty",
    };
  };
  if (estimate.status !== "ready") return fallback(estimate);
  const base = projectGraph(
    input.graph,
    input.filter === "fact" ? [] : [...input.operations],
    input.filter,
    input.positions,
    input.locale,
    [...input.references],
  );
  if (input.skipGroups) return { projection: base, base, estimate };
  const visual = estimateVisualWork(base, input.groups, input.collapsed);
  if (visual.status !== "ready")
    return fallback({ ...visual, counts: estimate.counts });
  return {
    projection: projectGroups(
      base,
      [...input.groups],
      [...input.collapsed],
      input.positions,
      input.locale,
    ),
    base,
    estimate: { ...visual, counts: estimate.counts },
  };
}
export function measurementsChanged(
  before: Record<string, Partial<LayoutBox>>,
  after: Record<string, Partial<LayoutBox>>,
): boolean {
  const ids = new Set([...Object.keys(before), ...Object.keys(after)]);
  for (const id of ids) {
    const a = before[id],
      b = after[id];
    if (
      !a ||
      !b ||
      a.width === undefined ||
      a.height === undefined ||
      b.width === undefined ||
      b.height === undefined ||
      Math.abs(a.width - b.width) > 1 ||
      Math.abs(a.height - b.height) > 1
    )
      return true;
  }
  return false;
}
export type OverviewSessionInput = Omit<
  VisibleLayoutInput,
  "priorGeometry" | "measurements"
> & {
  capture: OverviewCapture;
  measurementGeneration: number;
  blocked?: Record<string, boolean | undefined>;
};
export type OverviewSessionToken = OverviewCapture & {
  sequence: number;
  measurementGeneration: number;
};
type Pending = { status: "pending"; token: OverviewSessionToken };
export type OverviewSessionResult =
  Pending | VisibleLayoutResult | { status: "cancelled" };
const zero = (): GeometryWork => ({
  candidateProbes: 0,
  cellEntriesInserted: 0,
  liveCellEntries: 0,
  bucketEntryVisits: 0,
  rectangleComparisons: 0,
  manualPairObservations: 0,
  passes: 0,
});
export function sameOverviewCapture(
  a: OverviewCapture | undefined,
  b: OverviewCapture | undefined,
): boolean {
  return (
    !!a &&
    !!b &&
    a.projectId === b.projectId &&
    a.snapshotId === b.snapshotId &&
    a.projectionGeneration === b.projectionGeneration &&
    a.viewGeneration === b.viewGeneration
  );
}
/** Two pure layout passes form one atomic job. First positions remain private;
 * measured validation alone may publish positions, using cumulative counters. */
export class OverviewSession {
  private sequence = 0;
  private active?: {
    token: OverviewSessionToken;
    input: OverviewSessionInput;
    candidate: Extract<VisibleLayoutResult, { status: "ready" }>;
  };
  begin(input: OverviewSessionInput): OverviewSessionResult {
    this.cancel();
    if (Object.values(input.blocked ?? {}).some(Boolean))
      return { status: "cancelled" };
    const token = {
      ...input.capture,
      sequence: ++this.sequence,
      measurementGeneration: input.measurementGeneration,
    };
    const candidate = layoutVisibleOverview({
      ...input,
      measurements: {},
      priorGeometry: zero(),
    });
    if (candidate.status !== "ready") return candidate;
    this.active = { token, input, candidate };
    return { status: "pending", token };
  }
  measure(
    token: OverviewSessionToken,
    measurements: Record<string, LayoutBox>,
    current: OverviewCapture | undefined,
    measurementGeneration = token.measurementGeneration,
  ): OverviewSessionResult {
    const job = this.active;
    if (!job || job.token.sequence !== token.sequence)
      return { status: "cancelled" };
    if (
      !sameOverviewCapture(token, current) ||
      measurementGeneration !== token.measurementGeneration
    ) {
      this.cancel();
      return { status: "cancelled" };
    }
    // Read only the accepted visual scope. Unknown/old dimensions cannot complete it.
    const boxes: Record<string, LayoutBox> = {};
    for (const node of job.input.projection.nodes) {
      const box = measurements[node.id];
      if (!box) return { status: "pending", token };
      boxes[node.id] = { ...box };
    }
    this.active = undefined;
    return layoutVisibleOverview({
      ...job.input,
      measurements: boxes,
      priorGeometry: job.candidate.geometry,
    });
  }
  cancel() {
    this.active = undefined;
  }
}

export function saveCapturedVisualPosition(
  id: string,
  position: { x: number; y: number },
  capture: OverviewCapture | undefined,
  current: OverviewCapture | undefined,
  save: (
    patch: Record<string, { x: number; y: number }>,
    capture: OverviewCapture,
  ) => boolean,
): boolean {
  if (!capture || !sameOverviewCapture(capture, current)) return false;
  return save({ [id]: position }, capture);
}
