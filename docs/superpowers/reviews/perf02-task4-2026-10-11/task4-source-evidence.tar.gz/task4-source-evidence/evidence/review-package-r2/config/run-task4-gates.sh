#!/bin/bash
set -u
export PATH=/home/agent/.local/bin:$PATH
cd /home/agent/projects/AtlasMode-checkpoints/2026-10-11-perf02-task4/workspace
npx vitest run --config ../config/vitest.config.ts \
 apps/web/src/app/overview-layout.test.ts \
 apps/web/src/features/graph/overview-session.test.ts \
 apps/web/src/features/graph/Canvas.test.tsx \
 apps/web/src/app/workspace.test.ts \
 apps/web/src/features/graph/projection.test.ts \
 apps/web/src/features/groups/projection.test.ts \
 apps/web/src/api/client.test.ts \
 apps/server/src/layout-target.test.ts \
 apps/web/src/api/layout-target-client.test.ts \
 apps/web/src/app/workspace-ownership.test.ts \
 apps/web/src/app/inspection-workspace.test.ts \
 apps/web/src/app/funnel-workspace.test.ts \
 apps/web/src/app/group-collapse-workspace.test.ts \
 apps/web/src/app/WorkspacePanels.test.tsx \
 apps/web/src/features/structure/ownership-session.test.ts \
 apps/web/src/features/graph/funnel.test.ts \
 apps/web/src/features/graph/inspection.test.ts \
 apps/web/src/features/navigation/workspace-navigation.test.ts \
 apps/web/src/app/pol01-policy-sync.test.ts > ../evidence/task4-r2-tests.log 2>&1
rc=$?; tail -12 ../evidence/task4-r2-tests.log; [ "$rc" = 0 ] || exit "$rc"
npx tsc -p ../config/web-tsconfig.json > ../evidence/task4-r2-web-types.log 2>&1
rc=$?; cat ../evidence/task4-r2-web-types.log; [ "$rc" = 0 ] || exit "$rc"
npx tsc -p ../config/server-tsconfig.json > ../evidence/task4-r2-server-types.log 2>&1
rc=$?; cat ../evidence/task4-r2-server-types.log; [ "$rc" = 0 ] || exit "$rc"
npx eslint apps/server/src/queries.ts apps/server/src/routes.ts apps/web/src/api/client.ts apps/web/src/app/App.tsx apps/web/src/app/WorkspacePanels.tsx apps/web/src/app/pol01-policy-sync.test.ts apps/web/src/app/workspace-ownership.test.ts apps/web/src/app/workspace.ts apps/web/src/app/overview-layout.test.ts apps/web/src/features/graph/Canvas.tsx apps/web/src/features/graph/Canvas.test.tsx apps/web/src/features/graph/overview-session.ts apps/web/src/features/graph/overview-session.test.ts apps/web/src/i18n/en.ts apps/web/src/i18n/zh.ts packages/core/src/index.ts > ../evidence/task4-r2-lint.log 2>&1
rc=$?; cat ../evidence/task4-r2-lint.log; exit "$rc"
