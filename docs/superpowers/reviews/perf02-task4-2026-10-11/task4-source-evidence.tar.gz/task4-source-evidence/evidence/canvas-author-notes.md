# PERF02 Task4 Canvas/session author handoff

Scope: only Canvas.tsx, Canvas.test.tsx, overview-session.ts/test.ts, WorkspacePanels.tsx, zh.ts and en.ts. No projection, workspace, Plan schema, ownership protocol, source graph identity, MapPanel or FunnelOffsets source edits. No stage/commit/push/build/browser/Task5 work. Final source freeze: canvas-owned-source.sha256; author stopped product source writes after that manifest.

## Implemented

- guardedOverviewProjection runs bounded base preflight before projectGraph and group preflight before projectGroups. Refused plans/groups earn a separate graph+empty operations+fact+empty references projection; refused raw graph produces empty canvas. Original operations/filter/groups/view remain untouched.
- OverviewSession privately stages fallback pass, accepts complete actual current-visual measurements, then validates second pass with cumulative first-pass geometry. Rejected second pass has no positions. Scope/measurement token mismatch and interaction blocking cancel the job. Two passes maximum per session job.
- Canvas reads actual rendered ReactFlow measured cards only after projectionData adoption, ignores dimension changes <=1px, and has no pan/zoom layout dependency. Derived automatic positions stay in memory. Explicit reflow captures current visual IDs and ignores only their pins, then authorizes a current store patch before visual adoption. Stable navigation scope retains existing automatic points on expansion and keeps automatic cache through ordinary view writes.
- Ordinary drag captures scope at gesture start and writes one visual-key patch on stop; late project/view capture mismatches reject. Funnel drag keeps its existing root-scoped FunnelOffsets. Native ownership mode cancels layout jobs and does not create a pin. Panels blocks overview actions from accepted ownership mode/intent/saving plus dirty editor/group draft states.
- Separate project target totals/current facts/cards/routes, truncated query/refusal/counted lower bound, bounded fact-only/empty fallback, measured state and manual overlap diagnostics are visible. Both overview actions and funnel-specific rearrange wording have zh/en dictionary entries. Footer retains local unsaved view message from store state.

## Verification evidence

Commands use Node24 via export PATH=/home/agent/.local/bin:$PATH and source aliases --config ../config/vitest.config.ts, all from the authorized isolated workspace.

- canvas-session-red.log: setup failure only (remote noninteractive PATH lacked npx); not behavioral evidence.
- canvas-session-red-behavior.log: initial 13 failed/1 passed, including fixture early-exit errors; retained original.
- canvas-session-red-assertions.log: corrected assertion-only behavioral RED, 13 failed/1 passed.
- canvas-session-green-1.log: 2 failed/12 passed (truthful stored op counts; cumulative measured pass candidate accounting), retained.
- canvas-session-green-2.log: 14/14 passed.
- canvas-ui-red.log: real server-rendered Canvas, 4 failed.
- canvas-ui-green-1.log: 2 files18/18 passed.
- canvas-ui-green-2.log: 2 files21/21 passed, including actual second-pass 500-card3000x3000 live-entry cap rejection at20000 with no published positions; stale measurement generation; explicit alias scope unchanged.
- canvas-neighbor-green.log: 8 files111/111 passed (Canvas, session, overview-visual, graph/group projection, funnel, inspection, WorkspacePanels). This precedes the final two drag tests; not presented as a final-source full regression.
- canvas-drag-red.log: old drag scope erroneously accepted, 1 failed/18 passed.
- canvas-drag-green.log: final changed Canvas/session2 files23/23 passed (19 session,4 Canvas).
- canvas-lint-final.log: final seven-owned-file ESLint exit0. Formatting receipts canvas-format.log and canvas-drag-format.log.

## Rulings

- writing-good-tests is the TDD skill reference .agents/skills/test-driven-development/writing-good-tests.md, not a standalone skills directory. Read that reference.
- Separate pure session/projector behavior tests and real server-rendered Canvas tests keep algorithm/projection refusal proof outside framework mocks. SSR does not prove pointer/DOM/browser behavior; Task5 must supply those receipts.
- Stable navigation scope caches automatic visual points independently from captured generation. Every session still uses projection/view generation to reject stale work. Cost if wrong: scope cache may require targeted browser repair; no auto positions are persisted by default.

## Remaining gates and limitations

Independent critical review and controller final source typecheck/unified regression remain pending. No production worker bundle, actual browser pointer/measurement scheduling, 1600/1900 overlays, real-project timings, main-thread performance or native OS receipt was run. This handoff does not declare PERF02 complete or Task5 accepted. No full-root repeat was performed under the controller explicit proportional-check scope.
