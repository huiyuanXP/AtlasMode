### Task 3: 视觉镜像、位置来源与有界几何

**Files:** Create `apps/web/src/features/graph/overview-visual.ts`、`overview-visual.test.ts`。A窗仅import现projection/group types，不改GRP02/Canvas。

**Interfaces:**

- `Projection=ReturnType<typeof projectGraph>`，`estimateBaseVisualWork/resolveVisualPins/estimateVisualWork/layoutVisibleOverview`签名按spec。
- ready positions严格以已有visualIDs为key；`manualOverlaps:ManualOverlapDiagnostics`只报saved pins，GeometryWork计数语义与Task2相同；local最多两pass共用200000 visits/50000 comparisons/256 manual pair observations预算。首调用priorGeometry为零，第二调用传首返回累计计数，helper不突变它；Session不能重置同job budget。自动重叠不能伪报手动。
- input global ready canonical domain ranks与nodes.data.node.id关联，不通过split alias猜函数id。显式ignorePinsFor由Task4捕获当前visualIDs，不供正常default调用。

- [ ] **Step1 RED**：shared alpha在G1/G2是真同域、两个alias位置；first-alias oldcanonical pin唯一继承并返回sourceKey、自身alias key优先、group header key独立、offscopeopaque keys原样；base实际emission次数/ID冲突、501 nodes预检；两 loaded endpoints+2001 distinct合法add_relation拒绝edge_budget，projectGraph调用0/GraphEdge分配0、edge下界≥2001且不是render count；4097 visible ops只读length、operationVisits=0，fact filter忽略同列表但truthful stored length；≤4096的node-neutral annotate/move/remove触nested-work 2000001或allocation10001上界拒绝，预算cap/cap+1；graph301/relations901/references501拒绝无截断。exact group node数/route保守上界、15组每edge上界非225；groups4097/collapsedIds4097或member累计20001、groupSteps/alloc cap拒绝在projectGroups前且预检本身有界；保留原501 cards/2001 mirrored routes放大前拒绝以及collapsed source/target/handle/evidence身份不变fixture。filter=plan/both/fact按真实端点/referenced语义，accepted bound不得小于真实projectGraph访问/分配上界。
- [ ] **Step2 运行RED** `npx vitest run apps/web/src/features/graph/overview-visual.test.ts`。
- [ ] **Step3 实现pin/work helpers** 完全复用GRP02membership/首组stable排序规则；pre-projectGraph先length gate，再bounded maps/visits（至多两operation pass/8192 visits、两raw relation pass/1800 visits、两node pass/600 visits、一次references/500），按spec准确计算现有findLast/effectiveFunctionPath/removed.some的保守work上界；edge/node超限立即停并标partial_lower_bound，完整才标complete。estimateVisualWork bounded member scan且前置group nested-work/alloc预算。拒绝不含ReactFlow大数组、不改变Plan schema/operations/filter/groups/view。
- [ ] **Step4 geometry RED/GREEN** 加实际尺寸fixture（不同width/height、collapsed manyportheader、固定header/固定member/共享member、自动两点碰撞、manual两点重叠、world超大pin/64cells拒绝），实现局部block/格点、安全当前scopecompact；不重写edge endpoints/data，不加入physicalparent；两次测量条件由Task4驱动。添加local dense co-located/same-cell非相交、fixed pins+retained auto、新pin冲突、highdegree/longedge、多cell重复entry去重仍计visits、最终validation触cap fixture。断言每步真实visits/comparisons，local两pass总200000/50000/256 cap+1早拒绝、输出64 IDs/32 sample pairs且complete/truncated/lower-bound准确；禁止final allpairs漏计。运行同Step2，断言auto-auto/auto-pin无碰撞、pinsexact、no partialready/apply/save、数据深比不变。
- [ ] **Step5 A窗freeze独立review** 接口/geometrybudget/topologysemantic区别入原文，保留单测与真实DOM之间的未验证边界。

