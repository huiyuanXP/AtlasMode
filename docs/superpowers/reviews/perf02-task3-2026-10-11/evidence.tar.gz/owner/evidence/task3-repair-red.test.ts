import {describe,it,expect} from "vitest";
import type {CodeNode,FunctionGroup,SubgraphResult} from "@codemap/core";
import {projectGraph} from "../workspace/apps/web/src/features/graph/projection.js";
import {projectGroups} from "../workspace/apps/web/src/features/groups/projection.js";
import {estimateBaseVisualWork,estimateVisualWork,layoutVisibleOverview} from "../workspace/apps/web/src/features/graph/overview-visual.js";
import type {GeometryWork,GlobalLayoutResult} from "../workspace/apps/web/src/features/graph/overview-layout.js";
const node=(id:string):CodeNode=>({id,kind:"function",name:id,filePath:"a.ts"});
const group=(id:string,memberIds:string[]):FunctionGroup=>({id,memberIds,projectId:"p",title:id,description:"",source:"user"});
const zero=():GeometryWork=>({candidateProbes:0,cellEntriesInserted:0,liveCellEntries:0,bucketEntryVisits:0,rectangleComparisons:0,manualPairObservations:0,passes:0});
const graph=(ids:string[]):SubgraphResult=>({snapshotId:"s",dataSource:"code",truncated:false,nodes:ids.map(node),relations:[]});
const global=(ids:string[]):Extract<GlobalLayoutResult,{status:"ready"}>=>({status:"ready",positions:Object.fromEntries(ids.map((id,i)=>[id,{x:i*400,y:0}])),ranks:Object.fromEntries(ids.map(id=>[id,0])),order:ids,stats:{nodes:ids.length,rawRelations:0,rankRelations:0,sccs:ids.length,geometry:zero()},manualOverlaps:{affectedPinIds:[],samplePairs:[],pairsObserved:0,complete:true,truncated:false}});
describe("Independent review targeted RED against preserved author freeze",()=>{
 it("uses port-aware group fallback before any actual measurements",()=>{
  const g=graph(["0","1","2","3"]);g.relations=["0","1","2"].map(id=>({id:"r"+id,sourceId:id,targetId:"3",type:"calls",resolution:"resolved",evidence:{filePath:"a.ts",line:1}}));
  const projection=projectGroups(projectGraph(g,[],"fact",{}),[group("G",["0","1","2"])],["G"],{},"en");
  expect(projection.nodes.find(n=>n.id==="group:G")!.data.group!.portIds).toHaveLength(3);
  const out=layoutVisibleOverview({projection,global:global(["0","1","2","3"]),pins:{},retained:{},measurements:{},ignorePinsFor:[],priorGeometry:zero()});
  expect(out.status).toBe("ready");if(out.status!=="ready")return;
  const header=out.positions["group:G"]!,fact=out.positions["fact:3"]!;
  expect(header.x+360+48<=fact.x||fact.x+300+48<=header.x||header.y+400+48<=fact.y||fact.y+220+48<=header.y).toBe(true);
 });
 it("does not turn raw node length into emitted-card lower bound",()=>{
  const g=graph(Array.from({length:301},(_,i)=>String(i)));
  expect(projectGraph(g,[],"plan",{}).nodes).toHaveLength(0);
  expect(estimateBaseVisualWork(g,[],"plan",[])).toMatchObject({status:"rejected",reason:"node_budget",counts:{graphNodes:301},nodesLowerBound:0,countStatus:"partial_lower_bound"});
 });
 it("does not turn raw relation length into emitted-route lower bound",()=>{
  const g=graph(["0"]);g.relations=Array.from({length:901},(_,i)=>({id:String(i),sourceId:"0",targetId:null,type:"calls",resolution:"unresolved",evidence:{filePath:"a.ts",line:1}}));
  expect(projectGraph(g,[],"fact",{}).edges).toHaveLength(0);
  expect(estimateBaseVisualWork(g,[],"fact",[])).toMatchObject({status:"rejected",reason:"edge_budget",counts:{graphRelations:901},edgesLowerBound:0,countStatus:"partial_lower_bound"});
 });
 it("rejects opaque generated alias collisions before projectGroups",()=>{
  const base=projectGraph(graph(["c","b:c"]),[],"fact",{}),groups=[group("a:b",["c"]),group("a",["b:c"])];
  const actual=projectGroups(base,groups,[],{},"en");expect(actual.nodes.map(n=>n.id).filter(id=>id==="group-member:a:b:c")).toHaveLength(2);
  expect(estimateVisualWork(base,groups,[])).toMatchObject({status:"rejected",reason:"invalid_input"});
 });
});
