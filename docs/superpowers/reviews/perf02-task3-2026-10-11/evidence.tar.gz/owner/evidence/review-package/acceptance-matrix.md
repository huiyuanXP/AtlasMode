# Task3 acceptance matrix (author evidence; independent gate pending)

| Contract | Concrete implementation / evidence | Author result |
|---|---|---|
| Interfaces/ownership | Four typed exports; only two owned source/test files and owner config/evidence changed | PASS owned tsc/lint; independent API review pending |
| Pins/alias/domain identity | First stable localeCompare group fallback, own alias/header priority, collapsed first alias, opaque keys and colon-containing data.node.id | PASS unit |
| Exact emission/ID collision | 500 graph+plan cards accepted, 501 stopped; fact+plan same domain counted twice; duplicate node/edge visual IDs rejected | PASS unit |
| 2001 planned edge gate | Loaded true endpoints+2001 distinct ops; projectGraph call0, instrumented GraphEdge push0; no partial nodes/edgeUpperBound | PASS unit |
| Visible op4097/fact ignore | Proxy allows only length; stored4097 visible4097/0 and operationVisits0 | PASS unit |
| Graph/reference caps | graph301/relations901/references501 rejected before visits without truncation | PASS unit |
| Actual bounded reads | Six-op Proxy reads0 fact/12 plan,both; <=8192 op/1800 relation/500 ref; current helper indexes only | PASS unit + source inspection |
| Nested projectGraph upper bound | Current effectiveFunctionPath find+loop; matching move findLast; removal find/some; exact spec formula. Sample actual operation-read bound compared | PASS sampled unit + source inspection |
| Nested steps cap | 1404ops (1403moves), graph1, unused refs393 -> exact2000000 accepted; one more ref saturated2000001 rejected | PASS unit |
| Allocation cap | Fact+plan same domain/annotations: exact10000 accepted, target change saturated10001 rejected | PASS unit |
| Fact/plan/both semantics | Real projectGraph emissions compared to estimate with additions, references, annotate/remove, unresolved and missing endpoints | PASS unit |
| Group caps/member visits | groups4097/collapsed4097/member lengths20001 rejected before member read; metered20000 read once | PASS unit |
| Group visual bounds | 15 groups sharing two functions -> exact45 cards and routebound31 rather than225; amplified501/2001 early stop | PASS unit |
| Group nested/alloc work | Spec groupSteps saturation; member/loaded/index/affected/route/internal-ID/port/notice entries plus membership spread copies (also collapsed) | PASS unit; formula independent review pending |
| Measured blocks | Unequal dimensions, visible true-domain rank/order, fixed header/member/shared member, collapsed tall many-port header | PASS unit; actual DOM unrun |
| Pins/retained/collision | Pins exact; new pin releases only conflicting auto; safe retained points unchanged; autos never labeled manual | PASS unit |
| Numeric safety/box64 | Unsafe pin/dimensions rejected; measured3999 box at48/48 occupies64 and ready; next cell row rejects | PASS unit |
| Two passes/prior contract | Prior copied; pass1 allzero; prior validity before live reset; pass2 cumulative counters; pass3 rejected | PASS unit; session Task4 pending |
| Truthful geometry work | Two pins exactly2insert/5visits/2comparisons/1pair; multicell visits charged before dedup; dense80 samecell nonintersecting pins exact9560visits/6320comparisons | PASS unit |
| Cumulative exact caps | Candidate32000/insert40000/visit200000/compare50000/manual256: exact accepted; next actual work rejected before cap+1 | PASS unit |
| Live cap | 313 distributed measured pins exact20000 entries accepted; added row fails pin_insert at20000, no partial positions | PASS unit |
| Per-auto32 | Auto obstructed by32 saved points stops at32 actual candidates | PASS unit |
| Final validation | Cap+1 visit/comparison/manual failures occur at final_validation; same index/accounting, no all-pairs final loop | PASS unit |
| Diagnostics | 12 collocated pins66pairs complete/32samples;24pins256lower-bound incomplete;70disjoint overlaps complete with64IDs/32pairs | PASS unit |
| Dense auto/new conflicts | 80 collocated retained autos moved safely; new pins release only conflicting autos | PASS unit |
| Degree/long routes | 2000 routes kept byte/data-equal and not rasterized into geometry cells | PASS unit |
| Topology semantic preservation | Projection deep-equal, original collapsed source/target/handle/domain/evidence; no physical parent/membership/fact fabrication | PASS unit; Canvas Task4 pending |
| Rejected side effects | Rejected pure helper has no positions and does not own apply/save | PASS helper; actual UI Task4 pending |
| Performance | No real-project, DOM, worker/browser timing; test duration not product capability | NOT RUN Task4/5 |
| Full integration | Controller prohibited full-root repeat in old BASE/untracked assembly with missing unrelated compiled packages | NOT RUN explicit scope |
| Independent acceptance | Exact hashes/full diffs/snapshots/harness/logs/protection manifest | PENDING controller review |

Final unit gate:5 files/119 tests PASS (Task3 63/global27/controller18/graph6/groups5); owned noEmit typecheck and lint exit0. All baseline1387 paths unchanged, approved13/13 and pauseActual15/15 exact. Shared server deferred hunks retained. Source SHA and exact commands are in README/freeze-manifest.
