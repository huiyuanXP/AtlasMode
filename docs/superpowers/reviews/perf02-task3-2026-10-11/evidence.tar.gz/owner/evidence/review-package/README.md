# PERF02 Task3 author freeze for independent review

Owner `/home/agent/projects/AtlasMode-checkpoints/2026-10-11-perf02-task3`.
Workspace `owner/workspace`, branch `task/perf02-visual-20261011`, HEAD/base `ed793266b9dcac5cfa65f1a5358ec97d5184a69f`.
Status: implementation and scoped verification complete; independent review PENDING. No stage, commit, push, merge or deployment. Task4/5 integration and real DOM/performance acceptance are NOT included.

## Exact source freeze

- `overview-visual.ts`: `b0a72c07cc66b465c6ad61f09a4c58c98c213cbe67c0e641868fc922dd7fa566`
- `overview-visual.test.ts`: `5cb4e373e7c37dcc277d1ce259a2604bf35d18c63a541746b6e63700677a176b`

The source snapshots, complete `/dev/null` two-file diff and pause-to-resume incremental diff are in this package. `freeze-manifest.json` records source/config/log SHA, branch/base, status and protection audit. `dependency-assembly.json` records the exact 12 copied prior modules plus the core index type export. Do not stage only these two sources into an otherwise unassembled BASE: the workspace dependencies are deliberately untracked and required.

## Reproduce scoped verification

Use Node 24.19.0 and the existing private `workspace/node_modules` (prior offline ignore-scripts install). No build or service is needed. Owner-private configs are also copied under `review-package/config` for audit; run the originals under `owner/config` because relative paths refer to the owner/workspace arrangement.

```bash
export PATH=/home/agent/.local/bin:$PATH
cd /home/agent/projects/AtlasMode-checkpoints/2026-10-11-perf02-task3/workspace
npx --no-install vitest run --config ../config/vitest.config.mts \
  apps/web/src/features/graph/overview-visual.test.ts \
  apps/web/src/features/graph/projection.test.ts \
  apps/web/src/features/groups/projection.test.ts \
  apps/web/src/features/graph/overview-layout.test.ts \
  apps/web/src/features/graph/overview-layout-controller.test.ts
npx --no-install tsc -p ../config/tsconfig.owned.json
npx --no-install eslint apps/web/src/features/graph/overview-visual.ts apps/web/src/features/graph/overview-visual.test.ts
```

Vitest config uses core source alias, `maxWorkers:1`, `fileParallelism:false`. Typecheck includes the two owned files and their transitive source imports, `noEmit`, Bundler/ESNext, explicit Node typeRoots. Config changes are owner-private and do not change shared project resolution.

## Fresh verification evidence

- `baseline-resumed.log`: three unchanged projection/group/global suites, 38/38 PASS, 3.03s.
- `red-resumed.log`: original placeholders, true behavior RED, 34/34 FAIL, 1.04s. The older `red-preflight-and-geometry.log` remains untouched and is a setup failure, not feature RED.
- `green-task3-regression.log`: final five suites, 119/119 PASS (Task3 63, global 27, controller 18, graph 6, groups 5), 4.36s. Task3 fixture time 310ms is a test-run duration, not local production performance acceptance.
- `typecheck-owned-final.log`: exit 0, no output. Includes fixture types.
- `lint-owned-final.log`: exit 0, no output.
- `git diff --check`: exit 0. Untracked new-file content is additionally formatted by Prettier.

Preserved intermediate failures are evidence, not erased history. Original first green attempt was 33/34 because a paused fixture asked 100×16=1600 to reject at 2001; the fixture now has 134 valid routes. Paused schemas were corrected (`FunctionGroup` mandatory fields, unresolved/null Relation, typed layout input). Private typecheck first failed its external config typeRoots, then exposed those paused schema defects. Genuine later RED found prior counters reset before validation, nonzero first-pass acceptance, collapsed membership-copy allocation undercount, and a measurement-origin false rejection. Each was fixed after the corresponding failure. `green-task3-2.log` is intentionally a 61/63 FAIL record for the last 64-cell false rejection; the final regression is the passing follow-up.

## Preservation and remaining boundaries

`before-manifest.json`: 1387/1387 paths unchanged, zero sensitive paths encountered. All 13 assembly dependencies/core export match their approved expected hashes. All 15 current dependency files match pauseActual. Two server files differ from historical approved hashes exactly because shared server hunks remain deferred; neither was touched. Root tracked diff remains the original one-line core export and original untracked assembly files plus the two owned files.

Full root `npm test`, build, browser, DOM measurement/apply/save, session wiring, compiled scale and real project cold/hot timings were NOT run. Controller explicitly prohibited full-root repetition/expansion in this old BASE with untracked source assembly and missing unrelated compiled packages; necessary neighboring tests were used instead. Task4 must wire guarded calls/session generations/measurement passes, preserve job counters, and prove rejected results do not apply/save. Task5 must run correct assembled compiled integration and original real-project timing gates. No test timing here certifies 120ms local or worker p95 goals.

The pure helper returns complete position maps keyed by existing visual IDs and never mutates projection fields. It preserves saved pins exactly, keeps safe retained auto points, compacts visible true-domain ranks/order, and places unfixed expanded group cards/members as local translated blocks; fixed members remain independent obstacles. Geometry detects card rectangles, not semantic edge intersections. Routes/endpoints/handles/evidence and physical node identity are unchanged. It does not create domain membership edges, parents or facts. Edge arrays are checked by length and kept unchanged; rank/order are supplied by the already accepted global domain result. This topology/geometry distinction must remain visible in the independent review and later UI acceptance.
