# PERF02 Task3 R2 narrow repair freeze

Status: AUTHOR FREEZE FOR SCOPED RE-REVIEW, NOT APPROVED. The R1 reviewer requested changes (C0/I2/M1). Only those three findings were repaired, with four persisted owned regressions. No stage/commit/push, shared docs/dependency change, Task4/5 work, full-root repeat, build, service or browser run.

Workspace: `/home/agent/projects/AtlasMode-checkpoints/2026-10-11-perf02-task3/workspace`, branch `task/perf02-visual-20261011`, unchanged base `ed793266b9dcac5cfa65f1a5358ec97d5184a69f`.

Source SHA: `ce1aa93d597714c3975b53739ff658b1d72cbc8877064b6b45dbcce08781e979`.
Test SHA: `db89507d20f190316b8ce6fc93e73ad78ac3d695355030ff94f8947bdfef7e55`.

## Findings and scoped changes

- I1: The common size lookup now uses measured dimensions when present, otherwise code300×220 or group360×(220+60×portIds.length). The real collapsed fixture has three ports, hence fallback360×400; its adjacent fact must not overlap this box plus gap48. This corrects the previously false ready/no-collision claim for unmeasured group headers. Actual DOM remains unrun.
- I2: Raw graph length gates preserve exact counts.graphNodes/graphRelations but do not assign those lengths to emitted visual lower bounds. At a gate that performs no emission scan the visual lower bounds remain0. Plan with301 graph nodes and no operations has0 projected nodes;901 null-target relations have0 routes. They still reject their oversized raw input, without misleading visual counts.
- M1: Group preflight maintains at most500 accepted generated visual-ID strings, checks header/expanded-member identities and retained base visual IDs for duplicates, and rejects invalid_input before projectGroups. Opaque group/domain IDs remain unchanged; no splitting or identity guessing. The collision of (group a:b, member c) and (group a, member b:c) is now rejected. Collapsed groups generate no member aliases.

## Fresh evidence

`review-findings-red.log` retains the original four private review fixtures,4/4FAIL against R1. `r2-owned-repair-red.log` proves the persisted four formal tests were RED before the product fix. `r2-owned-repair-green.log` proves4/4GREEN afterward. Those two filtered runs intentionally deselect63 other Task3 tests and are not full-suite claims.

`r2-green-task3-regression.log`:5 files/123 tests PASS, zero skip (Task3 67/global27/controller18/graph6/groups5),4.43s. `r2-typecheck-owned.log` and `r2-lint-owned.log`:exit0, no output. These timings describe the test harness, not product performance capability.

Reproduce using existing Node24/private node_modules:

```bash
export PATH=/home/agent/.local/bin:$PATH
cd /home/agent/projects/AtlasMode-checkpoints/2026-10-11-perf02-task3/workspace
npx --no-install vitest run --config ../config/vitest.config.mts apps/web/src/features/graph/overview-visual.test.ts apps/web/src/features/graph/projection.test.ts apps/web/src/features/groups/projection.test.ts apps/web/src/features/graph/overview-layout.test.ts apps/web/src/features/graph/overview-layout-controller.test.ts
npx --no-install tsc -p ../config/tsconfig.owned.json
npx --no-install eslint apps/web/src/features/graph/overview-visual.ts apps/web/src/features/graph/overview-visual.test.ts
```

The configs copied under this package are audit snapshots of owner/config originals (their relative paths require the existing owner/workspace arrangement). Vitest remains one worker and no file parallelism; tsc remains noEmit and includes both owned files plus source imports. No dependency build is required.

`task3-r1-to-r2.diff` is the complete repair delta; `task3-new-files.diff` is the complete two-file new-product diff. Both exact sources, config snapshots, logs, dependency assembly and freeze-manifest are present. `package-sha256.json` freezes package bytes.

## Preservation and pending gates

All21 R1 package files match R1 package-sha256.json exactly. R1 original4FAIL/119GREEN and all earlier failures remain untouched. Baseline1387 paths unchanged, approved13 dependency/core hashes exact, pauseActual15 dependency hashes exact. The two server approved-hash differences remain the original deferred assembly hunks, not R2 changes.

Scoped independent re-review is pending; source repair is not an acceptance approval. Full-root compiled integration, Task4 Canvas/session/generations/measurement/apply/save and Task5 real project DOM/performance remain unrun as explicitly required by the controller. No test result removes those boundaries.
